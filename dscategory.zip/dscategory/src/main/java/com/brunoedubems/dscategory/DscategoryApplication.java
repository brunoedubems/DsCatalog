package com.brunoedubems.dscategory;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DscategoryApplication {

	public static void main(String[] args) {
		SpringApplication.run(DscategoryApplication.class, args);
	}

}
