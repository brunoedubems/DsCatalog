package com.brunoedubems.dscategory;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DscategoryApplicationTests {

	@Test
	void contextLoads() {
	}

}
